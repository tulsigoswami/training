require "test_helper"

class BookIssueRequestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
